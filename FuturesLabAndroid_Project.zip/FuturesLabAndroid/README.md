# FuturesLab Android app

This Android project packages the FuturesLab Binance Futures analyzer dashboard in a WebView-based Android app.

## Build an APK using only iPad + GitHub Actions

1. Sign in to GitHub in Safari on your iPad and create a **new private repository** (for example `FuturesLabAndroid`).
2. Download and extract `FuturesLabAndroid_Project.zip` in the iPad Files app.
3. In the new GitHub repository, use **Add file → Upload files** and upload the *contents* of the extracted `FuturesLabAndroid` folder, including the hidden `.github` folder and `.github/workflows/android-apk.yml`.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build FuturesLab APK** and tap **Run workflow** (or wait for the push-triggered build).
6. When the workflow finishes successfully, open that run, scroll to **Artifacts**, and download `FuturesLab-debug-apk`.
7. Extract the downloaded artifact on the iPad, transfer `app-debug.apk` to your Android phone (AirDrop is not available between iPad and Android; use Google Drive, USB, or another file-transfer method), then open it on Android and allow installation if prompted.

## Build locally

Open this folder in Android Studio with Android SDK Platform 35 and JDK 17, then run `gradle assembleDebug` or use **Build → Build APK(s)**.

## Included / limitations

- The dashboard HTML is bundled in `app/src/main/assets/index.html`.
- The app requires internet access for public Binance market endpoints and WebSocket streams.
- No Binance API key, order placement, or automatic trading is included.
- This project is source code plus a cloud-build workflow; it is **not** a compiled APK until the GitHub Actions workflow completes successfully.
- Verify live data availability and every trading level independently. Signals are not guaranteed and this is not financial advice.
